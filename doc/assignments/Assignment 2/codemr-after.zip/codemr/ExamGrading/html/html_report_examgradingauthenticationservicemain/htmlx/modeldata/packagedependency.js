var matrix = [[0,0,0,0],[2,0,1,0],[2,1,0,0],[0,0,0,0]]
var packages = [{
"name": " nl.tudelft.sem10.authenticationservice.application", "color": " #3182bd"
}
,{
"name": " nl.tudelft.sem10.authenticationservice.domain", "color": " #6baed6"
}
,{
"name": " nl.tudelft.sem10.authenticationservice.framework", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.sem10.authenticationservice", "color": " #c6dbef"
}
];
