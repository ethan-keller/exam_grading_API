var matrix = [[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,4,0,0,2],[0,0,0,0,0]]
var packages = [{
"name": " nl.tudelft.sem10.gradingservice.config", "color": " #3182bd"
}
,{
"name": " nl.tudelft.sem10.gradingservice.repositories", "color": " #6baed6"
}
,{
"name": " nl.tudelft.sem10.gradingservice", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.sem10.gradingservice.controllers", "color": " #c6dbef"
}
,{
"name": " nl.tudelft.sem10.gradingservice.entities", "color": " #e6550d"
}
];
