var EQ_workingSetList = [
{name: 'ExamGrading.AuthenticationService.main', path:'examgradingauthenticationservicemain'},
{name: 'ExamGrading.CourseService.main', path:'examgradingcourseservicemain'},
{name: 'ExamGrading.GradingService.main', path:'examgradinggradingservicemain'},
{name: 'ExamGrading.UserService.main', path:'examgradinguserservicemain'},
];
