var matrix = [[0,0,0,0,0],[0,0,0,0,0],[2,2,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]
var packages = [{
"name": " nl.tudelft.sem10.courseservice.repositories", "color": " #3182bd"
}
,{
"name": " nl.tudelft.sem10.courseservice.entities", "color": " #6baed6"
}
,{
"name": " nl.tudelft.sem10.courseservice.controllers", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.sem10.courseservice", "color": " #c6dbef"
}
,{
"name": " nl.tudelft.sem10.courseservice.config", "color": " #e6550d"
}
];
