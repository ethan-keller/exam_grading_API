var EQ_summaryInfo = [
{label:"high coupling, high complexity, low cohesion", color: "#E50000", value: 0,count:0},
{label:"high coupling, high complexity", color: "#FF5B13", value: 0,count:0},
{label:"high coupling", color: "#FFC800", value: 0,count:0},
{label:"high complexity", color: "#62BF18", value: 0,count:0},
{label:"fair quality attributes", color: "#007F24", value: 217,count:9}];
