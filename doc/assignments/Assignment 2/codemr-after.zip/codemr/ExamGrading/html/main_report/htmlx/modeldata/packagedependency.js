var matrix = [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,2,0,0,0,0,1,0,0,0,0,0,0,0,0],[0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,2,0,1,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,2],[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]]
var packages = [{
"name": " nl.tudelft.sem10.courseservice.repositories", "color": " #3182bd"
}
,{
"name": " nl.tudelft.sem10.courseservice.entities", "color": " #6baed6"
}
,{
"name": " nl.tudelft.sem10.courseservice.controllers", "color": " #9ecae1"
}
,{
"name": " nl.tudelft.sem10.userservice.application", "color": " #c6dbef"
}
,{
"name": " nl.tudelft.sem10.gradingservice.config", "color": " #e6550d"
}
,{
"name": " nl.tudelft.sem10.authenticationservice.application", "color": " #fd8d3c"
}
,{
"name": " nl.tudelft.sem10.gradingservice.repositories", "color": " #fdae6b"
}
,{
"name": " nl.tudelft.sem10.authenticationservice.domain", "color": " #fdd0a2"
}
,{
"name": " nl.tudelft.sem10.userservice.domain.repositories", "color": " #31a354"
}
,{
"name": " nl.tudelft.sem10.userservice", "color": " #74c476"
}
,{
"name": " nl.tudelft.sem10.authenticationservice.framework", "color": " #a1d99b"
}
,{
"name": " nl.tudelft.sem10.userservice.framework", "color": " #c7e9c0"
}
,{
"name": " nl.tudelft.sem10.courseservice", "color": " #756bb1"
}
,{
"name": " nl.tudelft.sem10.userservice.domain", "color": " #9e9ac8"
}
,{
"name": " nl.tudelft.sem10.authenticationservice", "color": " #bcbddc"
}
,{
"name": " nl.tudelft.sem10.courseservice.config", "color": " #dadaeb"
}
,{
"name": " nl.tudelft.sem10.gradingservice", "color": " #636363"
}
,{
"name": " nl.tudelft.sem10.gradingservice.controllers", "color": " #969696"
}
,{
"name": " nl.tudelft.sem10.gradingservice.entities", "color": " #bdbdbd"
}
];
